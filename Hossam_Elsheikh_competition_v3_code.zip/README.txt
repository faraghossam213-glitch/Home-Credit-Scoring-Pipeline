Hossam_Elsheikh — Competition v3 reproducibility package

This package regenerates Competition_Submission_v3.csv using only the official
competition input files: train.csv, test.csv, and sample_submission.csv.
No external data is used.

Requirements
  Python 3.10 or later
  pip install -r requirements.txt

Run both commands from this package folder, using the same input folder:
  python competition_model_v2.py --data-dir "PATH_TO_INPUT" --output output --folds 5
  python competition_model_v3.py --data-dir "PATH_TO_INPUT" --output output

The first command creates output/Competition_Submission_v2.csv. The second
trains CatBoost and blends its predictions with the five-fold LightGBM output,
creating output/Competition_Submission_v3.csv.

The CSV for Omnicampus is submitted separately. The competition rules say the
last prediction file submitted is the one used for final scoring. Keep this
code ZIP and the exact CSV submitted for reproducibility.
