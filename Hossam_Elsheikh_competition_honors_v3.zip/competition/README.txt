Hossam_Elsheikh — Competition reproducibility package

This ZIP contains the Colab notebook and model source needed to reproduce the
competition prediction file. It uses only the official train.csv, test.csv,
and sample_submission.csv provided for the assignment. The input data is not
included in this ZIP.

Before running in Colab, place this competition folder inside your Google Drive
folder that already contains the official input/ subfolder. Open competition.ipynb,
change WhereThisNotebookIsLocated to the full Drive path of this folder, then use
Runtime > Run all. The notebook trains the five-fold LightGBM model, trains the
CatBoost model, blends both, writes output/submission.csv, and compares it with
the included submission_v3_blend.csv reference.

The notebook's last cell creates competition.zip beside this folder for upload to
Omnicampus under Competition (.zip). Upload output/submission.csv separately to
the CSV submission field if the course page requests both files.
